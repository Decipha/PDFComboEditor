﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sharp.Gml;
using System.IO;

namespace XmlFormatCmd
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                Console.WriteLine("Usage: XmlFormatCmd %FileToOpen% %FileToSave%");
                Console.WriteLine();
            }

            string fileToOpen = args.FirstOrDefault();
            string fileToSave = args.LastOrDefault();

            while(string.IsNullOrWhiteSpace(fileToOpen) || !File.Exists(fileToOpen))
            {
                if (Directory.Exists(fileToOpen))
                {
                    Console.WriteLine($"Files In {Path.GetDirectoryName(fileToOpen)}");
                    foreach (var fn in Directory.EnumerateFiles(fileToOpen, "*.xml"))
                        Console.WriteLine(fn);
                }

                Console.WriteLine("Please Enter Path to File to Open");
                fileToOpen = Console.ReadLine();

            }

            if (string.IsNullOrWhiteSpace(fileToSave))
                fileToSave = fileToOpen;

            try {

                var doc = GmlDocument.Open(fileToOpen);
                Console.WriteLine($"Opened File {fileToOpen} Read {doc.Count()} Nodes");
                GmlDocument.Save(doc, fileToSave);
                Console.WriteLine($"Formatted Text Written to {fileToSave}");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                
            }
            finally
            {
                Console.ReadLine();
            }
        }
    }
}
