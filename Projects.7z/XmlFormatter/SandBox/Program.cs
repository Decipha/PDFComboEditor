﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SandBox
{
    class Program
    {
        static void Main(string[] args)
        {
            Evolution.X.Utility.ExpressionParser.StringTokenizer.Test();
        }
    }
}
