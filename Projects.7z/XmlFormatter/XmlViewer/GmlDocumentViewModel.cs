﻿using Microsoft.Win32;
using Sharp.Gml;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;

namespace XmlViewer
{
    /// <summary>
    /// view-model for markup language Viewer.
    /// </summary>
    public class GmlDocumentViewModel : INotifyPropertyChanged
    {
        /// <summary>
        /// has the markup been changed compared to the file?
        /// </summary>
        private bool _changed = false;

        /// <summary>
        /// backing field for file-name property.
        /// </summary>
        private string _fileName;

        /// <summary>
        /// backing field for editable markup
        /// </summary>
        private string _markup;

        /// <summary>
        /// the parsed gml document.
        /// </summary>
        private GmlDocument _document;

        /// <summary>
        /// returns true if the view-model has a document loaded into it.
        /// </summary>
        public bool HasDocument {  get { return _document != null; } }

        /// <summary>
        /// has the document changed?
        /// </summary>
        public bool IsChanged
        {
            get { return _changed; }
            set
            {
                if (_changed != value)
                {
                    _changed = value;
                    OnPropertyChanged(nameof(IsChanged));
                }

            }
        }



        /// <summary>
        /// gets or sets the file name of the current document.
        /// </summary>
        public string FileName
        {
            get { return _fileName; }
            set
            {
                if (_fileName != value)
                {
                    _fileName = value;
                    OnPropertyChanged(nameof(FileName));
                    OnPropertyChanged(nameof(Title));
                }
            }
        }

        public string Title => $"XML Viewer: {FileName}";


        /// <summary>
        /// gets or sets the string representation of the document's markup.
        /// </summary>
        public string Markup
        {
            get { return _markup;  }
            set
            {
                if (_markup != value)
                {
                    _markup = value;
                    OnPropertyChanged(nameof(Markup));
                    IsChanged = true;

                    // if the markup has changed, try to parse it into the document again.
                    try
                    {
                        Task.Run<GmlDocument>(() =>  GmlDocument.Parse(_markup)).ContinueWith((d) => this.Document = d.Result);
                    }
                    catch (Exception e)
                    {
                        MessageBox.Show($"Invalid Markup, {e.Message}");
                    }
                }
            }
        }


        /// <summary>
        /// returns the top nodes for display in a tree-view.
        /// </summary>
        public GmlTreeHierarchy Tree
        {
            get {

                if (_document != null)
                {
                    return new GmlTreeHierarchy(_document);
                }
                return null;

            }
        }

        /// <summary>
        /// gets or sets the current <see cref="GmlDocument"/>
        /// </summary>
        public GmlDocument Document
        {
            get { return _document; }
            set
            {
                if (_document != value)
                {
                    _document = value;
                    _markup   = _document.Markup;

                    OnPropertyChanged(nameof(Markup));
                    OnPropertyChanged(nameof(Document));
                    OnPropertyChanged(nameof(Tree));
                }

            }
        }

        public ObservableCollection<MenuItem> FileMenuItems
        {
            get
            {
                return new ObservableCollection<MenuItem>(new[] 
                {
                    new MenuItem() { Command = new RelayCommand(OpenFileUIAction, (o) => true),      Header = "Open"    },
                    new MenuItem() { Command = new RelayCommand(SaveUIAction,     (o) => IsChanged), Header = "Save"    },
                    new MenuItem() { Command = new RelayCommand(SaveAsUIAction,   (o) => true),      Header = "Save As" }
                });
            }

        }

        #region UI Actions

        private void OpenFileUIAction(object param)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "XML Files | *.xml| HTML files | *.htm";
            bool? rs = dlg.ShowDialog();
            if (rs.HasValue && rs.Value)
            {
                this.OpenFile(dlg.FileName);
            }
        }

        private void SaveUIAction(object param)
        {
            if (!HasDocument)
                return;

            if (MessageBox.Show("Overwrite Existing File?", "Save", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                Save();
            }
        }

        private void SaveAsUIAction(object param)
        {
            if (!HasDocument)
                return;

            SaveFileDialog dlg = new SaveFileDialog() { Title = "Save As", FileName = this.FileName, Filter = "XML Files | *.xml | HTML files | *.htm" };
            bool? rs = dlg.ShowDialog();
            if (rs.HasValue && rs.Value)
            {
                SaveAs(dlg.FileName);
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// open the specified file.
        /// </summary>
        /// <param name="fileName">the file to open</param>
        public void OpenFile(string fileName)
        {
            if (File.Exists(fileName))
            {
                
                Task.Run<GmlDocument>(() => 
                {
                    Application.Current.Dispatcher.InvokeAsync(() => Mouse.SetCursor(Cursors.Wait));
                    this.FileName = fileName;
                    return GmlDocument.Open(fileName);
                }).ContinueWith((d) =>
                {
                    this.Document = d.Result;
                    Application.Current.Dispatcher.InvokeAsync(() => Mouse.SetCursor(Cursors.Arrow));
                });
                

            }

        }

        /// <summary>
        /// saves the current markup over the original file
        /// </summary>
        public void Save()
        {
            File.WriteAllText(this.FileName, this.Markup);
            this.IsChanged = false;
        }

        /// <summary>
        /// saves the current markup to a new file and changes the current file name
        /// </summary>
        /// <param name="newFileName"></param>
        public void SaveAs(string newFileName)
        {
            // write the file
            File.WriteAllText(newFileName, this.Markup);

            // update the filename
            this.FileName = newFileName;

            // reset the changed flag:
            this.IsChanged = false;

        }

        #endregion

        #region INotifyPropertyChanged

        /// <summary>
        /// event raised when any property changes
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// raises the property changed event.
        /// </summary>
        /// <param name="name">
        /// the name of the property that changed.
        /// </param>
        protected void OnPropertyChanged(string name)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        #endregion  

    }

    /// <summary>
    /// used for populating trees via a <see cref="HierarchicalDataTemplate"/>
    /// </summary>
    public class GmlTreeHierarchy : IEnumerable<GmlTreeHierarchy>
    {
        /// <summary>
        /// the current node
        /// </summary>
        private GmlNode _node;

        /// <summary>
        /// construct the tree hierarchy from the specified node.
        /// </summary>
        /// <param name="node"></param>
        public GmlTreeHierarchy(GmlNode node)
        {
            _node = node;
        }

        public string OpenTagPrefix
        {
            get
            {
                if (_node is GmlComment)
                    return "<!--";
                else
                    return "<";
            }

        }

        public Brush PrefixSuffixColor
        {
            get
            {
                if (_node is GmlComment)
                    return Brushes.Green;
                else
                    return Brushes.Blue;
            }
        }

        public string OpenTagSuffix
        {
            get
            {
                if (_node is GmlComment)
                    return "-->";
                else
                {
                    if (_node.Children.Count == 0)
                        return "/>";
                    else
                        return ">";
                }

            }
        }

        public string OpenTag {  get { if (_node is GmlComment) return ((GmlComment)_node).Comment; return _node.Name; } }

        public string CloseTag
        {
            get
            {
                if (_node.TextOnlyChild)
                    return OpenTag;
                else
                    return "";

            }
        }

        public string CloseTagPrefix
        {
            get
            {
                if (_node.TextOnlyChild)
                    return "</";
                else
                    return "";

            }
        }

        public string CloseTagSuffix
        {
            get
            {
                if (_node.TextOnlyChild)
                    return ">";
                else
                {
                    return "";
                }
            }
        }


        public Brush TagColor
        {
            get
            {
                if (_node is GmlComment)
                    return Brushes.Green;
                if (_node is GmlElement)
                    return Brushes.DarkRed;

                return Brushes.Black;

            }
        }

        public string AttributeValues
        {
            get
            {
                var sb = new StringBuilder();
                foreach (var att in _node.Attributes)
                {
                    if (sb.Length == 0)
                        sb.Append(" ");
                    sb.Append(att.ToString()).Append(" ");
                }
                return sb.ToString();
            }
        }



        public string TextValue
        {
            get
            {
                if (_node.TextOnlyChild)
                {
                    return ((GmlText)_node.Children[0]).Value;
                }
                return "";
            }
        }

        /// <summary>
        /// the value to display for the current node.
        /// </summary>
        public string Value
        {
            get
            {
                if (_node.TextOnlyChild)
                    return $"[{_node.Name}] = '{ ((GmlText)_node.Children[0]).Value}'";
                else
                {
                    if (_node.Children.Count > 0)
                        return _node.ToString() + " (" + _node.Children.Count + ")";
                    else
                        return _node.ToString();
                }
            }
        }

        /// <summary>
        /// gets the path to the current node.
        /// </summary>
        public string NodePath
        {
            get { return _node.Path; }
        }

        /// <summary>
        /// gets the next level of nodes
        /// </summary>
        public IEnumerable<GmlTreeHierarchy> TreeItems { get { return this; } }

        /// <summary>
        /// enumerates the next level of nodes.
        /// </summary>
        /// <returns></returns>
        public IEnumerator<GmlTreeHierarchy> GetEnumerator()
        {
            // for parents of text nodes with only one child, don't yield any children (the text value is displayed at the node level)
            if (_node.TextOnlyChild)
                yield break;
            else
                foreach (var node in _node.Children)
                    yield return new GmlTreeHierarchy(node);

        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        public override string ToString()
        {
            return _node.ToString();
        }

        public static implicit operator GmlNode(GmlTreeHierarchy inNode)
        {
            return inNode._node;
        }


    }


    public class RelayCommand : ICommand
    {
        private Action<object>      _executeDelegate;
        private Predicate<object>   _canExecuteDelegate;

        public RelayCommand(Action<object> exec, Predicate<object> canExecute)
        {
            _executeDelegate    = exec;
            _canExecuteDelegate = canExecute;

            CommandManager.RequerySuggested += (s,e) => CanExecuteChanged?.Invoke(this, EventArgs.Empty);

        }


        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            if (_canExecuteDelegate != null)
                return _canExecuteDelegate(parameter);
            else
                return true;
        }

        public void Execute(object parameter)
        {
            if (_executeDelegate != null)
                _executeDelegate(parameter);
        }
    }
}
