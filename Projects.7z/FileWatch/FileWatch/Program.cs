﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileWatch
{
    /// <summary>
    /// XML serialization helper
    /// </summary>
    public static class Serializer
    {
        /// <summary>
        /// extension method to serialize objects to XML files
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="toSerialize">the object to serialize. Must be marked with the <see cref="SerializableAttribute"/></param>
        /// <param name="fileName">
        /// the target xml file.
        /// </param>
        public static void Serialize<T>(this T toSerialize, string fileName)
        {
            if (File.Exists(fileName))
                File.Delete(fileName);

            var xmls = new System.Xml.Serialization.XmlSerializer(typeof(T));
            using (var fs = File.OpenWrite(fileName))
            {
                xmls.Serialize(fs, toSerialize);
            }

        }

        /// <summary>
        /// de-serialize an object of specified type from the XML file specified
        /// </summary>
        /// <typeparam name="T">
        /// the type of object contained in the XML file
        /// </typeparam>
        /// <param name="fileName">
        /// the XML file to de-serialize
        /// </param>
        /// <returns>
        /// the de-serialized <typeparamref name="T"/>
        /// </returns>
        public static T DeSerialize<T>(string fileName) where T : class
        {
            if (!File.Exists(fileName))
                throw new FileNotFoundException("Cannot Find File!", fileName);

            var xmls = new System.Xml.Serialization.XmlSerializer(typeof(T));
            using (var fs = File.OpenRead(fileName))
            {
                var graph = xmls.Deserialize(fs) as T;
                if (graph != null)
                    return graph;
                else
                    throw new ApplicationException($"Failed to De-Serialize {typeof(T).Name} from {fileName} ");
            }
        }

    }

    /// <summary>
    /// a simple collection of files and folders in a hierarchy that can be stored to disk as an XML file.
    /// </summary>
    [Serializable]
    public class Folder : IEquatable<Folder>
    {
        #region Properties

        /// <summary>
        /// name of the folder
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// reference to parent folder
        /// </summary>
        [System.Xml.Serialization.XmlIgnore]
        public Folder Parent { get; set; }

        /// <summary>
        /// calculated full path to the folder
        /// </summary>
        public virtual string FullPath
        {
            get
            {
                if (Parent == null)
                    return this.Name;
                else
                {
                    return Path.Combine(Parent.FullPath, Name);
                }
                    
            }
        }

        /// <summary>
        /// list of files in the folder (file name only)
        /// </summary>
        public List<string> Files { get; set; } = new List<string>();

        /// <summary>
        /// list of sub-folders
        /// </summary>
        public List<Folder> Folders { get; set; } = new List<Folder>();

        #endregion

        #region Queries

        /// <summary>
        /// enumerate all the files in the hierarchy from this folder down
        /// </summary>
        public IEnumerable<string> AllFiles
        {
            get
            {
                // enumerate the local files first
                foreach (var f in Files)
                {
                    yield return Path.Combine(this.FullPath, f);
                }

                // enumerate the sub-folders
                foreach (var fld in Folders)
                {
                    // enumerate the AllFiles property in each sub-folder
                    foreach (var f in fld.AllFiles)
                    {
                        yield return f;
                    }
                }
            }
        }

        /// <summary>
        /// enumerates all folders in the hierarchy from this point down, starting with this folder.
        /// </summary>
        public IEnumerable<Folder> AllFolders
        {
            get
            {
                yield return this;

                foreach (var fld in Folders)
                {
                    foreach (var sfld in fld.AllFolders)
                        yield return sfld;
                }

            }
        }

        #endregion

        #region Ctor

        /// <summary>
        /// de-serialization constructor
        /// </summary>
        public Folder() { }

        /// <summary>
        /// default constructor: builds the hierarchy of folders using recursion.
        /// </summary>
        /// <param name="path"></param>
        /// <param name="parent"></param>
        public Folder(string path, Folder parent)
        {
            if (Directory.Exists(path))
            {
                var info = new DirectoryInfo(path);

                this.Name   = info.Name;
                this.Parent = parent;

                // store file names
                foreach (var fi in info.EnumerateFiles())
                {
                    Files.Add(fi.Name);
                }

                // store sub-folers:
                foreach (var sub in info.EnumerateDirectories())
                {
                    Folders.Add(new Folder(sub.FullName, this));
                }

            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// when de-serialized this reconnects the parent properties
        /// </summary>
        public void RestoreParents()
        {
            foreach (var folder in Folders)
            {
                folder.Parent = this;
                folder.RestoreParents();
            }
        }

        /// <summary>
        /// returns the full-path as the string - representation
        /// </summary>
        /// <returns></returns>
        public override string ToString() => FullPath;

        /// <summary>
        /// compares two folders (for <see cref="IEquatable{Folder}"/>)
        /// </summary>
        /// <param name="other"></param>
        /// <returns></returns>
        public bool Equals(Folder other)
        {
            return this.FullPath.Equals(other);
        }

        #endregion
    }

    /// <summary>
    /// derives from <see cref="Folder"/> to provide the top-level reference, adding the <see cref="RootPath"/> and <see cref="TimeStamp"/> properties
    /// </summary>
    [Serializable]
    public class FolderState : Folder, IEquatable<FolderState>
    {
        /// <summary>
        /// the date and time the folder collection was created
        /// </summary>
        public DateTime TimeStamp { get; set; } = DateTime.Now;

        /// <summary>
        /// the starting path for the folder collection
        /// </summary>
        public string RootPath { get; set; }

        /// <summary>
        /// override full path to use the root path so sub-folders can correctly calculate paths.
        /// </summary>
        public override string FullPath
        {
            get
            {
                return this.RootPath;
            }
        }

        /// <summary>
        /// deserialization constructor
        /// </summary>
        public FolderState() { }

        /// <summary>
        /// creates a snapshot of the files and folders under the specified path.
        /// </summary>
        /// <param name="path"></param>
        public FolderState(string path) : base(path, null)
        {
            this.RootPath = path;
        }

        /// <summary>
        /// loads a folder-state from an XML file.
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static FolderState Load(string fileName)
        {
            var fs = Serializer.DeSerialize<FolderState>(fileName);
                fs?.RestoreParents();

            return fs;
        }

        /// <summary>
        /// string representation: <see cref="RootPath"/>
        /// </summary>
        /// <returns></returns>
        public override string ToString() => this.RootPath;

        /// <summary>
        /// creates a hash-code from the <see cref="TimeStamp"/> and <see cref="RootPath"/>
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode() => string.Concat(this.RootPath, this.TimeStamp.ToString("yyMMddhhmmss")).GetHashCode();

        /// <summary>
        /// compares two objects for equality.
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            var fs = obj as FolderState;
            if (fs != null)
                return Equals(fs);
            else
                return base.Equals(obj);
        }

        /// <summary>
        /// compares two <see cref="FolderState"/>s for equality.
        /// </summary>
        /// <param name="fs"></param>
        /// <returns></returns>
        public bool Equals(FolderState fs)
        {
            return this.RootPath.Equals(fs.RootPath) && this.TimeStamp.Equals(fs.TimeStamp);
        }


        /// <summary>
        /// find any folders in b that are not in a.
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        public static IEnumerable<Folder> FoldersAdded(FolderState a, FolderState b)
        {
            if (a.RootPath.Equals(b.RootPath))
            {
                // find folders in last that are not in first.
                return from folder in b.AllFolders
                      where !a.AllFolders.Contains(folder)
                     select folder;
            }
            throw new ApplicationException("The two folders do not have the same root path");
        }

        /// <summary>
        /// find any folders removed from the first hierarchy (and thus are not in the second)
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        public static IEnumerable<Folder> FoldersRemoved(FolderState a, FolderState b)
        {
            if (a.RootPath.Equals(b.RootPath))
            {
                // find folders in a that are not in b.
                return from folder in a.AllFolders
                      where !b.AllFolders.Contains(folder)
                     select folder;
            }
            throw new ApplicationException("The two folders do not have the same root path");
        }

        /// <summary>
        /// find files in b that are not in a.
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        public static IEnumerable<string> FilesAdded(FolderState a, FolderState b)
        {
            return (from file in b.AllFiles
                   where !a.AllFiles.Contains(file)
                  select file);
        }

        /// <summary>
        /// find files in a that are not in b.
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        public static IEnumerable<string> FilesRemoved(FolderState a, FolderState b)
        {
            return (from file in a.AllFiles
                   where !b.AllFiles.Contains(file)
                  select file);
        }

    }

    /// <summary>
    /// records the details of a change to the file system.
    /// </summary>
    [Serializable]
    public class EventLogItem
    {
        #region Properties

        /// <summary>
        /// the date and time of the event
        /// </summary>
        public DateTime EventTime { get; set; }

        /// <summary>
        /// the type of event, eg, Created/Deleted/Renamed etc.
        /// </summary>
        public WatcherChangeTypes EventType { get; set; }

        /// <summary>
        /// friendly name of the file.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// fully qualified path to the file.
        /// </summary>
        public string FullPath { get; set; }

        #endregion

        #region Constructors

        /// <summary>
        /// de-serialization constructor
        /// </summary>
        public EventLogItem() { }

        /// <summary>
        /// default constructor, create from the file-system event args.
        /// </summary>
        /// <param name="fse"></param>
        public EventLogItem(FileSystemEventArgs fse)
        {
            this.EventTime = DateTime.Now;
            this.EventType = fse.ChangeType;
            this.FullPath = fse.FullPath;
            this.Name = fse.Name;
        }

        /// <summary>
        /// extended constructor: allows specification of the event time.
        /// </summary>
        /// <param name="fse"></param>
        /// <param name="time"></param>
        public EventLogItem(FileSystemEventArgs fse, DateTime time)
        {
            this.EventTime = time;
            this.EventType = fse.ChangeType;
            this.FullPath = fse.FullPath;
            this.Name = fse.Name;
        }

        #endregion
    }

    /// <summary>
    /// wraps around the <see cref="FileSystemWatcher"/> class to record the events it generates in a serializable form for analysis. writes the event details
    /// to the console in real-time.
    /// </summary>
    [Serializable]
    public class FileSystemTraceReport
    {
        #region Events

        /// <summary>
        /// event forwarded from the file-system monitor
        /// </summary>
        public event EventHandler<WatcherEventArgs> WatcherFileEvent;

        /// <summary>
        /// started event
        /// </summary>
        public event EventHandler WatcherStarted;

        /// <summary>
        /// stopped event
        /// </summary>
        public event EventHandler WatcherStopped;

        /// <summary>
        /// invoke the watcher file event
        /// </summary>
        /// <param name="details"></param>
        protected void OnWatcherFileEvent(EventLogItem details)
        {
            WatcherFileEvent?.Invoke(this, new WatcherEventArgs(details));
        }

        /// <summary>
        /// invoke the watcher started event
        /// </summary>
        protected void OnWatcherStarted()
        {
            WatcherStarted?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// invoke the watcher stopped event
        /// </summary>
        protected void OnWatcherStopped()
        {
            WatcherStopped?.Invoke(this, EventArgs.Empty);
        }

        #endregion

        #region Properties

        /// <summary>
        /// list of events
        /// </summary>
        public List<EventLogItem> EventLog { get; set; } = new List<EventLogItem>();

        /// <summary>
        /// record of files and folders under the watch path when the watcher starts
        /// </summary>
        public FolderState StartFileState { get; set; }

        /// <summary>
        /// record of files and folders under the watch path when the watcher stops
        /// </summary>
        public FolderState FinalFileState { get; set; }

        /// <summary>
        /// the path to watch
        /// </summary>
        public string WatchPath
        {
            get { return _monitor.Path;  }
            set { _monitor.Path = value; }
        }

        /// <summary>
        /// should sub-directories be watched?
        /// </summary>
        public bool IncludeSubDirectories
        {
            get { return  _monitor.IncludeSubdirectories; }
            set { _monitor.IncludeSubdirectories = value; }
        }

        /// <summary>
        /// calculates the duration of the watch.
        /// </summary>
        public TimeSpan Duration
        {
            get
            {
                if (StartFileState == null)
                    return TimeSpan.MinValue;

                if (FinalFileState != null)
                {
                    return FinalFileState.TimeStamp - StartFileState.TimeStamp;
                }
                else
                {
                    return DateTime.Now - StartFileState.TimeStamp;
                }

            }
        }

        /// <summary>
        /// the full path of the last output file.
        /// </summary>
        public string LastOutputFileName { get; protected set;  }

        #endregion

        #region Fields

        /// <summary>
        /// file-system watcher;
        /// </summary>
        private FileSystemWatcher _monitor = new FileSystemWatcher();

        /// <summary>
        /// started flag
        /// </summary>
        private bool _started = false;

        #endregion

        #region Constructors

        public FileSystemTraceReport() {

            _monitor.IncludeSubdirectories = true;
            _monitor.Changed += OnMonitorEvent;
            _monitor.Created += OnMonitorEvent;
            _monitor.Deleted += OnMonitorEvent;
            _monitor.Renamed += OnMonitorRenamedEvent;

            _monitor.NotifyFilter = NotifyFilters.Attributes    |
                                    NotifyFilters.CreationTime  |
                                    NotifyFilters.DirectoryName |
                                    NotifyFilters.FileName      |
                                    NotifyFilters.LastAccess    |
                                    NotifyFilters.LastWrite     |
                                    NotifyFilters.Security      |
                                    NotifyFilters.Size;
        }


        public FileSystemTraceReport(string path)
            : this()
        {
            this.WatchPath = path;
        }

        #endregion

        #region File System Watcher Event Handlers

        private void OnMonitorRenamedEvent(object sender, RenamedEventArgs e)
        {
            var logItem = new EventLogItem(e);
            EventLog.Add(logItem);

            WriteRenameToConsole(e);
            OnWatcherFileEvent(logItem);
        }

        private void OnMonitorEvent(object sender, FileSystemEventArgs e)
        {
            var logItem = new EventLogItem(e);
            EventLog.Add(logItem);
            WriteToConsole(e);
            OnWatcherFileEvent(logItem);
        }

        #endregion

        #region Colour Coded Console Writers

        /// <summary>
        /// write the details of a rename to the console
        /// </summary>
        /// <param name="e"></param>
        private static void WriteRenameToConsole(RenamedEventArgs e)
        {
            PrintTimeStamp();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("Renamed");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write(": ");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"From {e.OldFullPath} to {e.FullPath}");
        }

        /// <summary>
        /// writes a colourful message to the log indicating the file-system change that occurred.
        /// </summary>
        /// <param name="e"></param>
        private static void WriteToConsole(FileSystemEventArgs e)
        {
            PrintTimeStamp();
            switch (e.ChangeType)
            {
                case WatcherChangeTypes.Created:
                    Console.ForegroundColor = ConsoleColor.Green;
                    break;
                case WatcherChangeTypes.Deleted:
                    Console.ForegroundColor = ConsoleColor.Red;
                    break;
                case WatcherChangeTypes.Changed:
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    break;
                case WatcherChangeTypes.Renamed:
                    Console.ForegroundColor = ConsoleColor.Blue;
                    break;
                case WatcherChangeTypes.All:
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    break;
                default:
                    break;
            }
            Console.Write($"{e.ChangeType}");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write(": ");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(e.FullPath);
        }

        /// <summary>
        /// prints the current date and time to the console in yellow.
        /// </summary>
        private static void PrintTimeStamp()
        {
            ConsoleColor cc = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write(DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write(": ");
            Console.ForegroundColor = cc;
        }

        #endregion

        #region Start and Stop

        /// <summary>
        /// start watching the file system
        /// </summary>
        public void StartWatching()
        {
            // capture the initial folder state:
            this.StartFileState = new FolderState(this.WatchPath);

            // enable the file-system watcher
            _monitor.EnableRaisingEvents = true;

            // set the started flag:
            _started = true;

            // raise the event:
            OnWatcherStarted();
        }
        
        /// <summary>
        /// stop watching the file system
        /// </summary>
        public void StopWatching()
        {
            // was it started?
            if (_started)
            {
                // stop the file-system monitor from raising events
                _monitor.EnableRaisingEvents = false;

                // reset the flag
                _started = false;

                // capture the final state of the directory structure:
                this.FinalFileState = new FolderState(this.WatchPath);

                // raise the event:
                OnWatcherStopped();

            }
        }

        #endregion

        #region Serialization

        /// <summary>
        /// save the details of the trace to the specified xml file
        /// </summary>
        /// <param name="fileName"></param>
        public void Save(string fileName)
        {
            this.Serialize(fileName);
        }

        /// <summary>
        /// save the details of the trace to a date/time named file in the watch path
        /// </summary>
        public void Save()
        {
            Save(Path.Combine(this.WatchPath, DateTime.Now.ToString("yyyyMMddhhmm") + "_FileTraceReport.xml"));
        }

        /// <summary>
        /// load a <see cref="FileSystemTraceReport"/> from the specified xml file.
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static FileSystemTraceReport Load(string fileName)
        {
            var rpt = Serializer.DeSerialize<FileSystemTraceReport>(fileName);
                rpt.StartFileState.RestoreParents();
                rpt.FinalFileState.RestoreParents();

            return rpt;
        }

        #endregion
    }

    /// <summary>
    /// arguments for a file - watcher event
    /// </summary>
    public class WatcherEventArgs : EventArgs
    {
        public WatcherEventArgs(EventLogItem details)
        {
            EventDetails = details;
        }

        public EventLogItem EventDetails { get; }

    }

    class Program
    {
        static void Main(string[] args)
        {
            string path = null;

            if (args.Length != 1)
            {
                Console.WriteLine("No path argument supplied.");
                // get a valid path from the user:
                do
                {
                    Console.WriteLine("Please enter path of Directory to watch");
                    path = Console.ReadLine();

                    if (path.Equals("quit", StringComparison.OrdinalIgnoreCase))
                        return;

                } while (!Directory.Exists(path));
            }
            else
            {
                // validate the path exists:
                if (Directory.Exists(args[0]))
                {
                    path = args[0];
                }
                else
                {
                    Console.WriteLine("Invalid Path: " + args[0]);
                    return;
                }
            }

            // setup console:
            Console.WindowWidth = 160;
            Console.BufferWidth = 160;
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Clear();
            Console.Title = "Monitor: " + path;

            // create the trace reporter
            var rpt = new FileSystemTraceReport(path);
           
            try {
               
                // start watching:
                rpt.StartWatching();

                Console.WriteLine("Monitor Started. Hit Enter to End Watcher");
                Console.ReadLine();

                // stop the watcher:
                rpt.StopWatching();
            }
            finally
            {
                // save the log to the default, time-based file-name;
                rpt.Save();

                Console.WriteLine($"{rpt.EventLog.Count} events written to event log");

            }
            Console.ReadLine();

        }

    }
}
